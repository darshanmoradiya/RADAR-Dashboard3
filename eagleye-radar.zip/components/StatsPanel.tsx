import React from 'react';
import { motion } from 'framer-motion';
import { RawNetworkData } from '../types';
import { 
  Server, Monitor, Smartphone, Wifi, Shield, AlertTriangle, 
  Camera, Activity, Database, Terminal, Globe, Lock, AlertOctagon,
  Clock, CheckCircle2, Info
} from 'lucide-react';

interface StatsPanelProps {
  data: RawNetworkData;
}

const StatsPanel: React.FC<StatsPanelProps> = ({ data }) => {
  if (!data || !data.data || !data.data.devices) return null; // Defensive Check
  const { devices, scan_metadata, port_analysis } = data.data;

  // --- Calculate Category Counts ---
  const counts = {
    workstations: devices.records.filter(d => ['Desktop', 'Workstation', 'Laptop', 'Windows', 'Linux'].some(t => d.type.includes(t))).length,
    servers: devices.records.filter(d => ['Server', 'Ubuntu', 'CentOS', 'Debian'].some(t => d.type.includes(t))).length,
    switches: devices.records.filter(d => d.type === 'Switch').length,
    networkDevices: devices.records.filter(d => ['Router', 'Gateway', 'Firewall', 'WAP', 'Access Point'].some(t => d.type.includes(t))).length,
    smartphones: devices.records.filter(d => ['Android', 'iOS', 'Phone'].some(t => d.type.includes(t))).length,
    cameras: devices.records.filter(d => ['Camera', 'IP Camera'].some(t => d.type.includes(t))).length,
    highConfidence: devices.records.filter(d => d.confidence >= 80).length,
    lowConfidence: devices.records.filter(d => d.confidence < 40).length,
  };

  // --- Process Services (Ports) ---
  const serviceList = Object.entries(port_analysis || {}).map(([port, stats]) => {
    const portNum = parseInt(port);
    let name = 'Unknown';
    let risk: 'HIGH' | 'MEDIUM' | 'LOW' = 'LOW';
    let icon = <Activity className="w-4 h-4" />;

    if (portNum === 21) { name = 'FTP'; risk = 'HIGH'; icon = <Database className="w-4 h-4" />; }
    else if (portNum === 22) { name = 'SSH'; risk = 'LOW'; icon = <Terminal className="w-4 h-4" />; }
    else if (portNum === 23) { name = 'Telnet'; risk = 'HIGH'; icon = <Terminal className="w-4 h-4" />; }
    else if (portNum === 80) { name = 'HTTP'; risk = 'LOW'; icon = <Globe className="w-4 h-4" />; }
    else if (portNum === 443) { name = 'HTTPS'; risk = 'LOW'; icon = <Lock className="w-4 h-4" />; }
    else if (portNum === 445) { name = 'SMB'; risk = 'MEDIUM'; icon = <Server className="w-4 h-4" />; }
    else if (portNum === 3389) { name = 'RDP'; risk = 'MEDIUM'; icon = <Monitor className="w-4 h-4" />; }
    else if (portNum === 135) { name = 'MSRPC'; risk = 'LOW'; icon = <Activity className="w-4 h-4" />; }
    else if (portNum === 139) { name = 'NetBIOS'; risk = 'LOW'; icon = <Activity className="w-4 h-4" />; }
    else if (portNum === 53) { name = 'DNS'; risk = 'LOW'; icon = <Activity className="w-4 h-4" />; }

    return { port, name, risk, icon, count: stats.active_ports }; // Assuming active_ports maps to device count for this visualization context
  }).sort((a, b) => b.count - a.count); // Sort by prevalence

  const highRiskCount = serviceList.filter(s => s.risk === 'HIGH').length;

  const scanDuration = scan_metadata && scan_metadata[0] ? 
    Math.round((new Date(scan_metadata[0].end_time).getTime() - new Date(scan_metadata[0].start_time).getTime()) / 1000) + 's' 
    : 'N/A';
  
  const scanProtocol = scan_metadata && scan_metadata[0]?.snmp_version || 'SNMP v2c';

  const container = {
    hidden: { opacity: 0 },
    show: { opacity: 1, transition: { staggerChildren: 0.1 } }
  };

  const item = {
    hidden: { opacity: 0, y: 10 },
    show: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      variants={container}
      initial="hidden"
      animate="show"
      className="space-y-6 mb-6"
    >
      {/* 1. Network Header Banner */}
      <motion.div variants={item} className="bg-[#0f172a] rounded-xl border border-slate-700/50 p-5 flex flex-col md:flex-row justify-between items-start md:items-center shadow-lg relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-1 h-full bg-blue-500"></div>
        <div className="absolute inset-0 bg-blue-500/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
        
        <div className="z-10 mb-4 md:mb-0">
            <h2 className="text-xl font-bold text-white tracking-tight mb-1">Corporate Network</h2>
            <div className="flex items-center gap-3 text-sm">
                <span className="text-slate-400">All Devices • {devices.count} of {devices.count} devices</span>
            </div>
            <div className="mt-3 flex items-center gap-3">
                 <div className="bg-white text-slate-900 px-2 py-0.5 rounded text-xs font-bold font-mono border border-slate-200 shadow-sm">
                    172.16.16.0/24
                 </div>
                 <span className="text-xs text-slate-500">Main office network - {devices.count} devices detected</span>
            </div>
        </div>

        <div className="flex gap-3 z-10">
            <div className="flex items-center gap-2 bg-slate-800/50 border border-slate-700 px-3 py-1.5 rounded-lg">
                <Database className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-medium text-slate-300">{devices.count} Total Devices</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/50 border border-slate-700 px-3 py-1.5 rounded-lg">
                <Activity className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-medium text-slate-300">{scanProtocol}</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-800/50 border border-slate-700 px-3 py-1.5 rounded-lg">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-xs font-medium text-slate-300">Scan: {scanDuration}</span>
            </div>
            <div className="flex items-center gap-2 bg-emerald-500/10 border border-emerald-500/20 px-3 py-1.5 rounded-lg">
                <Activity className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                <span className="text-xs font-bold text-emerald-400">Live</span>
            </div>
        </div>
      </motion.div>

      {/* 2. Category Grid (4x2) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <StatCard 
            icon={<Monitor className="w-5 h-5" />}
            color="bg-blue-500"
            count={counts.workstations}
            label="Workstations"
            subtext="Windows/Linux hosts"
        />
        <StatCard 
            icon={<Server className="w-5 h-5" />}
            color="bg-emerald-500"
            count={counts.servers}
            label="Servers"
            subtext="Linux servers"
        />
        <StatCard 
            icon={<Activity className="w-5 h-5" />}
            color="bg-purple-500"
            count={counts.switches}
            label="Switches"
            subtext="Network switches"
        />
        <StatCard 
            icon={<Wifi className="w-5 h-5" />}
            color="bg-amber-600"
            count={counts.networkDevices}
            label="Network Devices"
            subtext="Printers, APs, etc."
        />
        
        <StatCard 
            icon={<Smartphone className="w-5 h-5" />}
            color="bg-cyan-500"
            count={counts.smartphones}
            label="Smartphones"
            subtext="Android & iOS"
        />
        <StatCard 
            icon={<Camera className="w-5 h-5" />}
            color="bg-pink-500"
            count={counts.cameras}
            label="IP Cameras"
            subtext="Hikvision & Dahua"
        />
        <StatCard 
            icon={<Shield className="w-5 h-5" />}
            color="bg-emerald-600"
            count={counts.highConfidence}
            label="High Confidence"
            subtext="≥80% confidence"
        />
        <StatCard 
            icon={<AlertTriangle className="w-5 h-5" />}
            color="bg-yellow-500"
            textColor="text-yellow-500"
            count={counts.lowConfidence}
            label="Low Confidence"
            subtext="<40% confidence"
        />
      </div>

      {/* 3. Detected Services Panel */}
      <motion.div variants={item} className="bg-[#0f172a] rounded-xl border border-slate-700/50 p-5 shadow-lg">
          <div className="flex justify-between items-center mb-4">
              <h3 className="text-sm font-bold text-white">Detected Services</h3>
              <span className="bg-slate-800 text-slate-400 text-[10px] px-2 py-1 rounded border border-slate-700">{serviceList.length} total</span>
          </div>
          
          {highRiskCount > 0 && (
             <div className="mb-4 bg-amber-500/10 border border-amber-500/20 rounded-lg p-3 flex items-center gap-3">
                 <AlertOctagon className="w-4 h-4 text-amber-500" />
                 <span className="text-xs font-bold text-amber-400">{highRiskCount} high-risk service(s) detected</span>
             </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3 max-h-[200px] overflow-y-auto custom-scrollbar pr-2">
            {serviceList.map((service, idx) => (
                <div key={`${service.port}-${idx}`} className="flex items-center justify-between p-3 bg-slate-900/50 border border-slate-800 rounded-lg group hover:border-slate-600 transition-colors">
                    <div className="flex items-center gap-3">
                        <div className="p-2 bg-slate-800 rounded-md text-slate-400 border border-slate-700 group-hover:text-white transition-colors">
                            {service.icon}
                        </div>
                        <div>
                            <div className="text-xs font-bold text-slate-200">{service.name}</div>
                            <div className="text-[10px] text-slate-500 font-mono">Port {service.port}</div>
                        </div>
                    </div>
                    <div className="flex items-center gap-3">
                        <span className="text-xs text-slate-500">{service.count} devices</span>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${
                            service.risk === 'HIGH' ? 'bg-red-500/10 text-red-400 border-red-500/20' : 
                            service.risk === 'MEDIUM' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 
                            'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        }`}>
                            {service.risk}
                        </span>
                    </div>
                </div>
            ))}
            {serviceList.length === 0 && (
                <div className="col-span-2 text-center py-8 text-slate-500 text-xs italic">
                    No services detected in scan data.
                </div>
            )}
          </div>
      </motion.div>
    </motion.div>
  );
};

const StatCard = ({ icon, color, count, label, subtext, textColor }: any) => {
    // Helper to extract the color class for text/border if generic
    const borderClass = color.replace('bg-', 'border-').replace('600', '500').replace('500', '500') + '/20';
    const bgClass = color.replace('bg-', 'bg-') + '/10';
    
    return (
        <motion.div 
            variants={{ hidden: { opacity: 0, scale: 0.95 }, show: { opacity: 1, scale: 1 } }}
            className="bg-[#0f172a] rounded-xl border border-slate-700/50 p-4 hover:border-slate-500/50 transition-colors group flex items-start gap-4 shadow-md"
        >
            <div className={`p-2.5 rounded-lg shrink-0 ${bgClass} ${textColor ? textColor : 'text-white'}`}>
                {React.cloneElement(icon, { className: `w-6 h-6 ${textColor ? '' : 'text-white'}` })}
            </div>
            <div>
                <div className="text-2xl font-bold text-white mb-0.5">{count}</div>
                <div className="text-xs font-semibold text-slate-300">{label}</div>
                <div className="text-[10px] text-slate-500 mt-0.5">{subtext}</div>
            </div>
        </motion.div>
    );
};

export default StatsPanel;